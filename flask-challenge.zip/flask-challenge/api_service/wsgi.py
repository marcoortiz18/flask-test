from api_service.app import create_app

app = create_app()
