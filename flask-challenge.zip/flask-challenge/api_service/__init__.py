# encoding: utf-8

# Force loading of models, so they are taken into account when we run migration commands.
from api_service import models
