# encoding: utf-8

from flask_marshmallow import Marshmallow

marsh = Marshmallow()
